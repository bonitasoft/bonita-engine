import java.io.PrintWriter;
import java.util.Locale;
import java.io.OutputStream;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import org.bonitasoft.web.extension.page.PageController;
import org.bonitasoft.web.extension.page.PageResourceProvider;
import org.bonitasoft.web.extension.page.PageContext;
import org.bonitasoft.engine.api.IdentityAPI;
import org.bonitasoft.engine.identity.User;
import org.bonitasoft.engine.session.APISession;

import org.bonitasoft.engine.api.TenantAPIAccessor;

public class Index implements PageController {

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response, PageResourceProvider pageResourceProvider, PageContext pageContext) {
        try {
            InputStream input = pageResourceProvider.getResourceAsStream("index.html")
            OutputStream out = response.getOutputStream();
            byte[] buf = new byte[1024];
            int len;
            while ((len = input.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
            input.close();
            out.flush();
            out.close();
        } catch (Exception e) {
            e.printStackTrace();
        } 
    }

}
