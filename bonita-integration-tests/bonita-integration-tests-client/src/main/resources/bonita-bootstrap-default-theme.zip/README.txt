#The name must start with 'custompage_'
name=custompage_bootstrapdefaulttheme
displayName=Default theme
description=This is a dummy default theme
contentType=theme
version=7.0.1