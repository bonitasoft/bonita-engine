#The name must start with 'custompage_'
displayName=Bootstrap default theme
name=custompage_bootstrapdefaulttheme
description=Application theme based on bootstrap "Default" theme. (see http\://bootswatch.com/default/)
contentType=theme
version=7.0.1