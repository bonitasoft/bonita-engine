Customer-Application Version 2 Changes


Pages :
- Health Page updated : 
    dispalname changed from -> "Health check page" to "Healthz check page"
- Reports Page Added

Apps :
- application.xml updated :
    page token changed from -> "health" to "Healthz"
- application2.xml added

RestExt API:
- processStarter updated :
    dispalname changed from -> "Process Starter REST API" to "Process Starter API"
    version changed from -> 1.0 to 1.1

bdm :
- field "version" added on BonitaDomain table

orga :
- user "captainReports", role "reportsManager", group "reportsManagement"

processes:
- update version of callHealthCheck to 1.1
- add new HealthCheckDispatcher process (version 1.0)
