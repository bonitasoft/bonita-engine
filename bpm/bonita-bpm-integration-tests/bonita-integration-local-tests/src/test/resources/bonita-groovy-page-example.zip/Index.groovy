return '''<!DOCTYPE html>
<html>
  <head>
    <title>My custom page</title>
  </head>
  <body>
    <p>Hello world!</p>
  </body>
</html>'''