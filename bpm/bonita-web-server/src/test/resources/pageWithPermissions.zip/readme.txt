This is a custom page example archive for Bonita BPM Portal.

You can customize this custom page by modifying the existing resources or by adding or removing some.

Examples provided in the archive:

Write simple text
Get information provided in the groovy class
Retrieve the URL of a resource of the custom page
Call the Bonita BPM Engine APIs using the current session
URL to an external page
Get localized string from resources bundles

Content detail:

Index.groovy				Index.groovy is the entry point used by the portal to display the custom page
resources					Directory containing the web resources
resources/css				Directory containing CSS files used by the example
resources/img				Directory of images.
resources/js				Directory containing javascript files used by the example
lib							Directory containing jar files used by the example add added to Index.groovy class loader
page.properties				Contains meta-data informations: name,displayName and description. this file is use by the engine at platform startup and page add/update
readme.txt					this file
