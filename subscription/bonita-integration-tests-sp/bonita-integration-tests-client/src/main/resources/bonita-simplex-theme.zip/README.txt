#The name must start with 'custompage_'
displayName=Simplex theme
name=custompage_simplextheme
description=Application theme based on Bootstrap "Simplex" theme. (see http://bootswatch.com/simplex/)
contentType=theme
version=7.0.1